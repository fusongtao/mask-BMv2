

last_label = 0x0a000303
next_label = 0x0a000305
auth=0x33322
k0_1=0x11111111
k0_2=0x22222222
k1=0x123
k2=0x456
epoch_seq_flag=0
#        0     1    2      3     4    5     6     7      8    9     A      B    C     D     E     F[256]
sbox = [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76, #0
        0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0, #1
        0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15, #2
        0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75, #3
        0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84, #4
        0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf, #5
        0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8, #6
        0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2, #7
        0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73, #8
        0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb, #9
        0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79, #A
        0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08, #B
        0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a, #C
        0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e, #D
        0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf, #E
        0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16 ] #F

def shiftx(a,x):
    a = (a >> x)& 0xff
    return a


def shiftadd(a,b,x,y):
    c = ((b >> x)& 0x1)<<y
    if y == 0:
        a = (a & 0xfffffffe)
    elif y == 1:
        a = (a & 0xfffffffd)
    elif y == 2:
        a = (a & 0xfffffffb)
    elif y == 3:
        a = (a & 0xfffffff7)
    elif y == 4:
        a = (a & 0xffffffef)
    elif y == 5:
        a = (a & 0xffffffdf)
    elif y == 6:
        a = (a & 0xffffffbf)
    elif y == 7:
        a = (a & 0xffffff7f)
    elif y == 8:
        a = (a & 0xfffffeff)
    elif y == 9:
        a = (a & 0xfffffdff)
    elif y == 10:
        a = (a & 0xfffffbff)
    elif y == 11:
        a = (a & 0xfffff7ff)
    elif y == 12:
        a = (a & 0xffffefff)
    elif y == 13:
        a = (a & 0xffffdfff)
    elif y == 14:
        a = (a & 0xffffbfff)
    elif y == 15:
        a = (a & 0xffff7fff)
    elif y == 16:
        a = (a & 0xfffeffff)
    elif y == 17:
        a = (a & 0xfffdffff)
    elif y == 18:
        a = (a & 0xfffbffff)
    elif y == 19:
        a = (a & 0xfff7ffff)
    elif y == 20:
        a = (a & 0xffefffff)
    elif y == 21:
        a = (a & 0xffdfffff)
    elif y == 22:
        a = (a & 0xffbfffff)
    elif y == 23:
        a = (a & 0xff7fffff)
    elif y == 24:
        a = (a & 0xfeffffff)
    elif y == 25:
        a = (a & 0xfdffffff)
    elif y == 26:
        a = (a & 0xfbffffff)
    elif y == 27:
        a = (a & 0xf7ffffff)
    elif y == 28:
        a = (a & 0xefffffff)
    elif y == 29:
        a = (a & 0xdfffffff)
    elif y == 30:
        a = (a & 0xbfffffff)
    elif y == 31:
        a = (a & 0x7fffffff)
    return a+c

def cal_sbox(c1,c2,c3,c4,r1,r2,r3,r4,k1):
    c1 = shiftx(k1,24) ^ sbox[c1]
    c2 = shiftx(k1,16) ^ sbox[c2]
    c3 = shiftx(k1,8) ^ sbox[c3]
    c4 = shiftx(k1,0) ^ sbox[c4]
    r1 = shiftx(k1,56) ^ sbox[r1]
    r2 = shiftx(k1,48) ^ sbox[r2]
    r3 = shiftx(k1,40) ^ sbox[r3]
    r4 = shiftx(k1,32) ^ sbox[r4]
    return c1,c2,c3,c4,r1,r2,r3,r4

def p1(r,c1,c2,c3,c4,r1,r2,r3,r4):
    r = shiftadd(r,c3,2,31)
    r = shiftadd(r,c2,1,30)
    r = shiftadd(r,r3,6,29)
    r = shiftadd(r,c1,2,28)
    r = shiftadd(r,c3,7,27)
    r = shiftadd(r,r4,7,26)
    r = shiftadd(r,r4,5,25)
    r = shiftadd(r,c4,7,24)
    r = shiftadd(r,r1,6,23)
    r = shiftadd(r,c1,1,22)
    r = shiftadd(r,c1,7,21)
    r = shiftadd(r,c3,4,20)
    r = shiftadd(r,c3,0,19)
    r = shiftadd(r,c1,4,18)
    r = shiftadd(r,c4,4,17)
    r = shiftadd(r,c4,2,16)
    r = shiftadd(r,r2,5,15)
    r = shiftadd(r,c2,5,14)
    r = shiftadd(r,c1,0,13)
    r = shiftadd(r,r4,3,12)
    r = shiftadd(r,r1,1,11)
    r = shiftadd(r,r1,2,10)
    r = shiftadd(r,r3,0,9)
    r = shiftadd(r,r3,4,8)
    r = shiftadd(r,c4,1,7)
    r = shiftadd(r,r2,1,6)
    r = shiftadd(r,r1,5,5)
    r = shiftadd(r,r4,2,4)
    r = shiftadd(r,c3,1,3)
    r = shiftadd(r,r1,7,2)
    r = shiftadd(r,r2,0,1)
    r = shiftadd(r,r2,6,0)
    return r

def p2(r,c1,c2,c3,c4,r1,r2,r3,r4):
    r = shiftadd(r,r4,0,31)
    r = shiftadd(r,c3,5,30)
    r = shiftadd(r,c1,3,29)
    r = shiftadd(r,c2,2,28)
    r = shiftadd(r,c4,6,27)
    r = shiftadd(r,c4,3,26)
    r = shiftadd(r,r1,4,25)
    r = shiftadd(r,c3,3,24)
    r = shiftadd(r,r2,2,23)
    r = shiftadd(r,r3,1,22)
    r = shiftadd(r,c3,6,21)
    r = shiftadd(r,c1,5,20)
    r = shiftadd(r,c4,5,19)
    r = shiftadd(r,r3,5,18)
    r = shiftadd(r,r4,6,17)
    r = shiftadd(r,c2,0,16)
    r = shiftadd(r,r4,4,15)
    r = shiftadd(r,c4,0,14)
    r = shiftadd(r,r2,7,13)
    r = shiftadd(r,r2,4,12)
    r = shiftadd(r,c2,4,11)
    r = shiftadd(r,r1,0,10)
    r = shiftadd(r,r3,7,9)
    r = shiftadd(r,c2,6,8)
    r = shiftadd(r,r3,2,7)
    r = shiftadd(r,r2,3,6)
    r = shiftadd(r,r3,3,5)
    r = shiftadd(r,c1,6,4)
    r = shiftadd(r,c2,7,3)
    r = shiftadd(r,c2,3,2)
    r = shiftadd(r,r1,3,1)
    r = shiftadd(r,r4,1,0)
    return r

def final_p1(r,c1,c2,c3,c4,r1,r2,r3,r4):
    r = shiftadd(r,c4,0,31)
    r = shiftadd(r,c4,5,30)
    r = shiftadd(r,c2,5,29)
    r = shiftadd(r,c2,0,28)
    r = shiftadd(r,c1,4,27)
    r = shiftadd(r,r3,2,26)
    r = shiftadd(r,r1,4,25)
    r = shiftadd(r,c4,4,24)
    r = shiftadd(r,r4,3,23)
    r = shiftadd(r,c4,2,22)
    r = shiftadd(r,r2,4,21)
    r = shiftadd(r,c3,1,20)
    r = shiftadd(r,c3,4,19)
    r = shiftadd(r,c3,7,18)
    r = shiftadd(r,r4,0,17)
    r = shiftadd(r,c4,3,16)
    r = shiftadd(r,r1,6,15)
    r = shiftadd(r,c3,3,14)
    r = shiftadd(r,r3,4,13)
    r = shiftadd(r,r3,6,12)
    r = shiftadd(r,c2,3,11)
    r = shiftadd(r,c2,7,10)
    r = shiftadd(r,c3,6,9)
    r = shiftadd(r,c1,5,8)
    r = shiftadd(r,r3,0,7)
    r = shiftadd(r,r4,2,6)
    r = shiftadd(r,c3,5,5)
    r = shiftadd(r,c2,1,4)
    r = shiftadd(r,r2,3,3)
    r = shiftadd(r,c1,1,2)
    r = shiftadd(r,r2,0,1)
    r = shiftadd(r,r4,7,0)
    return r

def final_p2(r,c1,c2,c3,c4,r1,r2,r3,r4):
    r = shiftadd(r,r1,5,31)
    r = shiftadd(r,c2,4,30)
    r = shiftadd(r,c3,2,29)
    r = shiftadd(r,r1,0,28)
    r = shiftadd(r,r1,1,27)
    r = shiftadd(r,c1,0,26)
    r = shiftadd(r,r4,4,25)
    r = shiftadd(r,r2,1,24)
    r = shiftadd(r,c4,1,23)
    r = shiftadd(r,c2,2,22)
    r = shiftadd(r,r3,1,21)
    r = shiftadd(r,c1,6,20)
    r = shiftadd(r,r1,3,19)
    r = shiftadd(r,r4,6,18)
    r = shiftadd(r,c1,2,17)
    r = shiftadd(r,r2,5,16)
    r = shiftadd(r,c4,7,15)
    r = shiftadd(r,c2,6,14)
    r = shiftadd(r,r1,7,13)
    r = shiftadd(r,c4,6,12)
    r = shiftadd(r,r2,7,11)
    r = shiftadd(r,c3,0,10)
    r = shiftadd(r,r3,3,9)
    r = shiftadd(r,r2,6,8)
    r = shiftadd(r,c1,3,7)
    r = shiftadd(r,r4,5,6)
    r = shiftadd(r,r2,2,5)
    r = shiftadd(r,c1,7,4)
    r = shiftadd(r,r1,2,3)
    r = shiftadd(r,r3,5,2)
    r = shiftadd(r,r3,7,1)
    r = shiftadd(r,r4,1,0)
    return r

def cal_em(epoch_seq_flag,last_label,next_label,auth,k0_1,k0_2,k1,k2):
    new_message = last_label ^ next_label
    #xor_with_key_1
    new_rnd=auth ^ epoch_seq_flag
    new_message=new_message^k0_1
    new_rnd = new_rnd ^ k0_2
    mark_src = new_rnd
    #init_lookup_key_rnd
    r1 = shiftx(mark_src ,24)
    r2 = shiftx(mark_src,16) 
    r3 = shiftx(mark_src ,8)
    r4 = shiftx(mark_src ,0)
    #init_lookup_key_message
    c1 = shiftx(new_message,24)
    c2 = shiftx(new_message,16) 
    c3 = shiftx(new_message,8)
    c4 = shiftx(new_message,0)
    #print ("new_mess:",new_message&0xff,"c1:",c1,"c2:",c2,"c3:",c3,"c4:",c4)
    #SBOX k1
    c1,c2,c3,c4,r1,r2,r3,r4 = cal_sbox(c1,c2,c3,c4,r1,r2,r3,r4,k1)
    #p1
    mark_r=p1(0,c1,c2,c3,c4,r1,r2,r3,r4)
    #p2
    mark_src=p2(0,c1,c2,c3,c4,r1,r2,r3,r4)
    new_message = mark_r

    #print ("mark_r:",mark_r,"--mark_src:",mark_src,"c:",(c1<<24)+(c2<<16)+(c3<<8)+c4,"r:",(r1<<24)+(r2<<16)+(r3<<8)+r4,"new_message:",new_message)
    #print ("new_rnd:",new_rnd,"k1:",k1,"k2:",k2)
    #init_lookup_key_rnd
    r1 = shiftx(mark_src ,24)
    r2 = shiftx(mark_src,16) 
    r3 = shiftx(mark_src ,8)
    r4 = shiftx(mark_src ,0)
    #init_lookup_key_message
    c1 = shiftx(new_message,24)
    c2 = shiftx(new_message,16) 
    c3 = shiftx(new_message,8) 
    c4 = shiftx(new_message,0)
    #print ("new_mess2:",new_message&0xff,"c1:",c1,"c2:",c2,"c3:",c3,"c4:",c4)
    #print ("r:",new_message,"r1:",r1,"r2:",r2,"r3:",r3,"r4:",r4,"srcmark",hex(mark_src))
    #SBOX k2
    c1,c2,c3,c4,r1,r2,r3,r4 = cal_sbox(c1,c2,c3,c4,r1,r2,r3,r4,k2)
    
    #print ("new_mess3:",new_message&0xff,"c1:",c1,"c2:",c2,"c3:",c3,"c4:",c4)
    mark_r=final_p1(0,c1,c2,c3,c4,r1,r2,r3,r4)
    mark_src=final_p2(0,c1,c2,c3,c4,r1,r2,r3,r4)
    #print ("new_mess4:",new_message&0xff,"c1:",c1,"c2:",c2,"c3:",c3,"c4:",c4)
    print ("mark_r:",mark_r,hex(mark_r),"--mark_src:",mark_src,hex(mark_src))
    #print ("c:",(c1<<24)+(c2<<16)+(c3<<8)+c4,"r:",(r1<<24)+(r2<<16)+(r3<<8)+r4,"new_message:",new_message,"new_rnd:",new_rnd)
    return mark_src,mark_r


def main():
    cal_em(epoch_seq_flag,last_label,next_label,auth,k0_1,k0_2,k1,k2)

if __name__ == '__main__':
    main()
    
