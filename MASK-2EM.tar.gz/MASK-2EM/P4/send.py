#!/usr/bin/env python

import sys
import logging
import struct
import random
from scapy.layers.inet import _IPOption_HDR
from scapy.all import *
from headerNew import *
import time,datetime
import headerNew

from utils.srAPI import *


path = list_label[0]+list_label[1]+list_label[2]+list_label[3]+list_label[4]
payload = "path :"+ str(list_label[0])+str(list_label[1])+str(list_label[2])+str(list_label[3])+str(list_label[4])
timestamp = 0x1234

def main():
    if len(sys.argv) < 2:
        logging.info('pass 2 arguments: <type>  ')
        exit(1)
    
    epoch = 0
    global src
    src=""
    for turns in range(4):
        #calculate the adjust factor
        n = new_policy(epoch)
        for seq in range(n):        
            k=random.randint(0, HOPS-1) 
            #k=1
            send_data(epoch,seq,0,k,payload)  
        epoch +=1     
        #time.sleep(SLEEP_TIME) 
    
def send_data(epoch,seq,packet_type,i,pay_load):    
    iface = get_if()
    tag=0xff000078
    flag = packet_type
    if packet_type == ACK:
        pay_load_enc = pay_load
    if seq >=0:
        pay_load=str( int(round((time.time()) * 1000000)))+"*"+pay_load
        for count_i in range(100):
            pay_load +="0"
        message = int(pay_load[len(pay_load)-4:len(pay_load)-1])
        dataauth=sip_hash(message, key_src, key_src_2) & 0xffffffff
        #print "dataauth:",dataauth,"message:",message,"pay_load:",pay_load
        enc_label = list_label[i] 
        epoch_seq_flag = ((flag<<24) +(epoch<<16) + seq) & 0xffffffff
        k0_1,k0_2,k1,k2=get_skey(sk_sw[i])
        mac,mac_r = send_marking(epoch_seq_flag,i,dataauth,k0_1,k0_2,k1,k2)
        #print "mac:",mac          
        pkt =  Ether(src=get_if_hwaddr(iface), dst='ff:ff:ff:ff:ff:ff',type=0x86dd)
        if packet_type == ACK:
            pkt = pkt /IPv6(src = src_dst_str[1],dst = src_dst_str[0],nh=143,tc=0,hlim=10)
            pay_load = pay_load_enc
        else:
            pkt = pkt /IPv6(src = src_dst_str[0],dst = src_dst_str[1],nh=143,tc=0,hlim=10)
        
        pkt = pkt/trustke(flag=packet_type,epoch=epoch,seq=seq,session=tag,label=enc_label,dataauth=dataauth,mac=mac)
        pkt = pkt/ts()/pay_load
        #/mac_temp()/TCP(dport=1234, sport=49152)
        pkt.show2()
        print "src_counter:",src_counter
        sendp(pkt, iface=iface, verbose=False)

if __name__ == '__main__':
    main()
